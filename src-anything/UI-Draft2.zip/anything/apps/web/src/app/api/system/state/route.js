import sql from "@/app/api/utils/sql";

export async function GET() {
  try {
    const rows =
      await sql`SELECT maintenance_mode, display_enabled, updated_at FROM system_state WHERE id = 1`;
    if (rows.length === 0) {
      return Response.json({ maintenance_mode: false, display_enabled: true });
    }
    return Response.json(rows[0]);
  } catch (err) {
    console.error("GET /api/system/state error:", err);
    return new Response("Internal server error", { status: 500 });
  }
}

export async function PATCH(request) {
  try {
    const body = await request.json();
    const { maintenance_mode, display_enabled } = body;

    const sets = [];
    const values = [];
    let idx = 1;

    if (maintenance_mode !== undefined) {
      sets.push(`maintenance_mode = $${idx++}`);
      values.push(maintenance_mode);
    }
    if (display_enabled !== undefined) {
      sets.push(`display_enabled = $${idx++}`);
      values.push(display_enabled);
    }
    sets.push(`updated_at = NOW()`);

    if (sets.length === 1) return Response.json({ ok: true });

    const query = `UPDATE system_state SET ${sets.join(", ")} WHERE id = 1`;
    await sql(query, values);

    return Response.json({ ok: true });
  } catch (err) {
    console.error("PATCH /api/system/state error:", err);
    return new Response("Internal server error", { status: 500 });
  }
}
